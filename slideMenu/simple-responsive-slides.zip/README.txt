A Pen created at CodePen.io. You can find this one at http://codepen.io/tonkec/pen/waqBOW.

 Simple responsive slides with keyboard control. Enjoy! 